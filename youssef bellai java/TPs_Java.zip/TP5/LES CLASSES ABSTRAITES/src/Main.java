abstract class Generale {
    public int x=2;
    abstract public void qui();
    public void moi(){
        System.out.println("Méthode générale");
    }
}
