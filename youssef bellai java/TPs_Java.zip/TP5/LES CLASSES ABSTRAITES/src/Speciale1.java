class Speciale1 extends Generale{
    public void qui() {

        System.out.println("C'est la sous-classe Speciale1");
    }
    public void moi(){
        System.out.println("Méthode moi avec la class Speciale1");
    }

}
