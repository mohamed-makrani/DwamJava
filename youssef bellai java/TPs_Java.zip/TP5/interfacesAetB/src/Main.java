class C implements A, B {

    public void  f(){
        System.out.println("La methode f()");
    }
     public void g() {


}

}