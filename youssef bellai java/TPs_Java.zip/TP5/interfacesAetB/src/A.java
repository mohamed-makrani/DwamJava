public interface A {
    public int x  = 0;
    public void  f();
    default void g() {};

}
