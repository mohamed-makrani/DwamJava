public class Test {


    C c = new C();
    A c0 = new C();

}
