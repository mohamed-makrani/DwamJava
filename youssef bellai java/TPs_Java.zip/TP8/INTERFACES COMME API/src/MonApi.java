interface MonApi {

    public void print();
    public String convTexte();
    public int compare (Object o);
}
